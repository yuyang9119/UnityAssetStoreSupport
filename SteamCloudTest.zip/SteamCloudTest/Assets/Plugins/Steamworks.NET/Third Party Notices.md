This package contains third-party software components governed by the license(s) indicated below:

Component Name: Steamworks.NET

License Type: "MIT"

[Steamworks.NET License](https://github.com/rlabrecque/Steamworks.NET/blob/master/LICENSE.txt)
