﻿using UnityEngine;
using System.Collections;
using System;
using Steamworks;
using Rand = UnityEngine.Random;

public class GameController : MonoBehaviour
{
    public static event Action waitForEndOfFrame;
    const string fileName = "Manager";


    void Awake()
    {
        if (!SteamworksHelper.Init(480))
        {
#if UNITY_EDITOR
            UnityEditor.EditorApplication.isPlaying = false;
#else
            Application.Quit();
#endif
            return;
        }

        StartCoroutine(WaitForEndOfFrame());

        ReadAsync();
    }


    IEnumerator WaitForEndOfFrame()
    {
        var wait = new WaitForEndOfFrame();

        while (true)
        {
            yield return wait;
            waitForEndOfFrame?.Invoke();
        }
    }


    private void OnDestroy()
    {
        SteamworksHelper.Shutdown();
    }


    private void OnGUI()
    {
        if (GUILayout.Button("ReadAsync")) ReadAsync();

        if (GUILayout.Button("WriteAsync")) WriteAsync();
    }


    void ReadAsync()
    {
        if (!CallResultEvent<RemoteStorageFileReadAsyncComplete_t>.TryMonitor(
            SteamRemoteStorage.FileReadAsync(fileName, 0, (uint)SteamRemoteStorage.GetFileSize(fileName)),
            OnReadComplete))
        {
            Debug.Log("[FileReadAsync] Invalid SteamAPICall_t.");
        }
    }


    void WriteAsync()
    {
        var buffer = new byte[] { (byte)Rand.Range(0, 256), (byte)Rand.Range(0, 256), (byte)Rand.Range(0, 256), (byte)Rand.Range(0, 256) };
        if (!CallResultEvent<RemoteStorageFileWriteAsyncComplete_t>.TryMonitor(
            SteamRemoteStorage.FileWriteAsync(fileName, buffer, (uint)buffer.Length),
            OnWriteComplete))
        {
            Debug.Log("[FileWriteAsync] Invalid SteamAPICall_t.");
        }
    }


    void OnReadComplete(RemoteStorageFileReadAsyncComplete_t param, bool bIOFailure)
    {
        if (param.m_eResult != EResult.k_EResultOK || bIOFailure)
        {
            Debug.Log($"[OnReadComplete] m_eResult: {param.m_eResult}, bIOFailure: {bIOFailure}");
        }
        else
        {
            var buffer = new byte[param.m_cubRead];
            if (!SteamRemoteStorage.FileReadAsyncComplete(param.m_hFileReadAsync, buffer, param.m_cubRead))
            {
                Debug.Log("[OnReadComplete] FileReadAsyncComplete return false.");
            }
            else
            {
                string result = string.Empty;
                for (int i = 0; i < buffer.Length; i++)
                {
                    if (i != 0) result += ", ";
                    result += buffer[i];
                }
                Debug.Log($"[OnReadComplete] Result: {result}");
            }
        }
    }


    void OnWriteComplete(RemoteStorageFileWriteAsyncComplete_t param, bool bIOFailure)
    {
        if (param.m_eResult != EResult.k_EResultOK || bIOFailure)
        {
            Debug.Log($"[OnWriteComplete] m_eResult: {param.m_eResult}, bIOFailure: {bIOFailure}");
        }
        else
        {
            Debug.Log($"[OnReadComplete] Result: OK");
        }
    }
}
