﻿using UnityEngine;
using System.Collections;
using System;
using Steamworks;
using Rand = UnityEngine.Random;

public class GameController : MonoBehaviour
{
    public static event Action waitForEndOfFrame;
    (string name, string message)[] files;


    void Awake()
    {
        if (!SteamworksHelper.Init(480))
        {
#if UNITY_EDITOR
            UnityEditor.EditorApplication.isPlaying = false;
#else
            Application.Quit();
#endif
            return;
        }

        StartCoroutine(WaitForEndOfFrame());

        files = new (string name, string message)[10];
        for (int i = 0; i < files.Length; i++)
        {
            files[i] = ("File" + i, string.Empty);
            ReadAsync(i);
        }
    }


    IEnumerator WaitForEndOfFrame()
    {
        var wait = new WaitForEndOfFrame();

        while (true)
        {
            yield return wait;
            waitForEndOfFrame?.Invoke();
        }
    }


    private void OnDestroy()
    {
        SteamworksHelper.Shutdown();
    }


    private void OnGUI()
    {
        for (int i = 0; i < files.Length; i++)
        {
            GUILayout.BeginHorizontal();

            GUILayout.Label(files[i].name, GUILayout.Width(40));

            if (GUILayout.Button("Read Async", GUILayout.Width(100))) ReadAsync(i);

            if (GUILayout.Button("Write Async", GUILayout.Width(100))) WriteAsync(i);

            GUILayout.Label(files[i].message);

            GUILayout.EndHorizontal();
        }

        GUILayout.Space(20);

        if (GUILayout.Button("Delete All"))
        {
            DeleteAllCloudFiles();
        }
    }


    void ReadAsync(int index)
    {
        if (!CallResultEvent<RemoteStorageFileReadAsyncComplete_t>.TryMonitor(
            SteamRemoteStorage.FileReadAsync(files[index].name, 0, (uint)SteamRemoteStorage.GetFileSize(files[index].name)),
            (param, bIOFailure) => OnReadComplete(index, param, bIOFailure)))
        {
            files[index].message = "[FileReadAsync] Invalid SteamAPICall_t";
        }
    }


    void WriteAsync(int index)
    {
        var buffer = new byte[] { (byte)Rand.Range(0, 256), (byte)Rand.Range(0, 256), (byte)Rand.Range(0, 256), (byte)Rand.Range(0, 256) };
        if (!CallResultEvent<RemoteStorageFileWriteAsyncComplete_t>.TryMonitor(
            SteamRemoteStorage.FileWriteAsync(files[index].name, buffer, (uint)buffer.Length),
            (param, bIOFailure) => OnWriteComplete(index, param, bIOFailure)))
        {
            files[index].message = "[FileWriteAsync] Invalid SteamAPICall_t.";
        }
    }


    void OnReadComplete(int index, RemoteStorageFileReadAsyncComplete_t param, bool bIOFailure)
    {
        if (param.m_eResult != EResult.k_EResultOK || bIOFailure)
        {
            files[index].message = $"[OnReadComplete] m_eResult: {param.m_eResult}, bIOFailure: {bIOFailure}";
        }
        else
        {
            var buffer = new byte[param.m_cubRead];
            if (!SteamRemoteStorage.FileReadAsyncComplete(param.m_hFileReadAsync, buffer, param.m_cubRead))
            {
                files[index].message = "[OnReadComplete] FileReadAsyncComplete return false.";
            }
            else
            {
                int value = 0;
                for (int i = 0; i < buffer.Length; i++)
                {
                    value |= buffer[i] << i * 8;
                }
                files[index].message = $"[OnReadComplete] Value: {value}";
            }
        }
    }


    void OnWriteComplete(int index, RemoteStorageFileWriteAsyncComplete_t param, bool bIOFailure)
    {
        if (param.m_eResult != EResult.k_EResultOK || bIOFailure)
        {
            files[index].message = $"[OnWriteComplete] m_eResult: {param.m_eResult}, bIOFailure: {bIOFailure}";
        }
        else
        {
            files[index].message = "[OnWriteComplete] OK";
        }
    }


#if UNITY_EDITOR
    [UnityEditor.MenuItem("Tools/Steamworks/Delete All Cloud Files")]
#endif
    public static void DeleteAllCloudFiles()
    {
        if (UnityEngine.Application.isPlaying)
        {
            int count = SteamRemoteStorage.GetFileCount();
            for (int i = count - 1; i >= 0; i--)
            {
                var name = SteamRemoteStorage.GetFileNameAndSize(i, out _);
                SteamRemoteStorage.FileDelete(name);
            }
        }
    }
}
